﻿namespace Final_Exam
{
    enum Materie
    {
        Romana,
        Matematica,
        Informatica,
        Istorie,
        Geografie,
        Sport,
        Biologie,
        Chimie,
        Logica
    }
}