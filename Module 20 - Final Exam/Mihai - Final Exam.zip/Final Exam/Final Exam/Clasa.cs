﻿namespace Final_Exam
{
    enum Clasa
    {
        nouaA,
        nouaB,
        nouaC,
        nouaD,
        zeceA,
        zeceB,
        zeceC,
        zeceD,
        unsprezeceA,
        unsprezeceB,
        unsprezeceC,
        unsprezeceD,
        doisprezeceA,
        doisprezeceB,
        doisprezeceC,
        doisprezeceD
    }
}